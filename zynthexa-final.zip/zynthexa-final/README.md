# ZYNTHEXA 🚀

Sitio web oficial de ZYNTHEXA — Creando el Futuro de la Humanidad.

## Estructura del proyecto

```
zynthexa/
├── index.html        ← Página principal
├── api/
│   └── chat.js       ← Función serverless para el chatbot IA
├── vercel.json       ← Configuración de seguridad de Vercel
└── README.md
```

## Cómo funciona el chatbot

El chatbot usa la API de Anthropic (Claude). Para activarlo:

1. Ve a [console.anthropic.com](https://console.anthropic.com)
2. Crea una cuenta y genera una API key
3. Abre el sitio, haz clic en el botón 💬 e ingresa tu API key

## Despliegue

Este proyecto está desplegado en Vercel y conectado al dominio `zynthexa.com`.

Cada vez que subas cambios a GitHub, Vercel actualiza el sitio automáticamente.

## Seguridad

- Headers de seguridad configurados en vercel.json
- Validación y sanitización de inputs en api/chat.js
- Rate limiting de 15 mensajes por minuto
- API key almacenada en sessionStorage (se borra al cerrar el tab)
- Protección XSS en todas las entradas y salidas
- Bloqueo de solicitudes mayores a 50KB

© 2026 ZYNTHEXA
